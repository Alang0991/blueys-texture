Shader "Blueys/BlueysTexture"
{
    Properties
    {
        [HideInInspector] _Cull ("Cull", Float) = 2

        [Header(Main)]
        _MainTex ("Main Image Texture", 2D) = "white" {}
        _Color ("Texture Tint", Color) = (1,1,1,1)
        _MainTexTiling ("Tiling", Vector) = (1,1,0,0)
        _MainTexOffset ("Offset", Vector) = (0,0,0,0)
        _Alpha ("Transparency", Range(0,1)) = 1

        [Header(Brightness & Color)]
        _Brightness ("Brightness", Range(0,3)) = 1
        _Contrast ("Contrast", Range(0,3)) = 1
        _Saturation ("Saturation", Range(0,3)) = 1
        _HueShift ("Hue Shift", Range(-180,180)) = 0
        _Gamma ("Gamma", Range(0.1,3)) = 1
        _Vibrance ("Vibrance", Range(-1,1)) = 0
        _Sharpness ("Sharpness", Range(0,2)) = 0

        [Header(Lighting)]
        [Toggle] _UseToonLighting ("Toon Lighting", Float) = 0
        [Toggle] _UseCelShading ("Cel Shading", Float) = 0
        _ShadowColor ("Shadow Color", Color) = (0.1,0.1,0.2,1)
        _ShadowStrength ("Shadow Strength", Range(0,1)) = 0.5
        _ShadowThreshold ("Shadow Threshold", Range(0,1)) = 0.5
        _ShadowSmoothness ("Shadow Smoothness", Range(0.01,0.5)) = 0.1
        _ToonLightDir ("Toon Light Direction", Vector) = (0,1,0,0)
        [Toggle] _UseShadeRamp ("Shade Ramp Texture", Float) = 0
        _ShadeRampTex ("Shade Ramp", 2D) = "white" {}

        [Toggle] _UseRimLight ("Rim Light", Float) = 0
        _RimColor ("Rim Color", Color) = (0.35,0.9,1,1)
        _RimPower ("Rim Tightness", Range(0.5,8)) = 3
        _RimStrength ("Rim Strength", Range(0,8)) = 2
        _RimWidth ("Rim Width", Range(0,1)) = 0.5
        _RimMask ("Rim Mask", 2D) = "white" {}

        [Toggle] _UseFresnel ("Fresnel", Float) = 0
        _FresnelColor ("Fresnel Color", Color) = (0.35,0.9,1,1)
        _FresnelPower ("Fresnel Power", Range(0.5,8)) = 3
        _FresnelStrength ("Fresnel Strength", Range(0,8)) = 2

        [Toggle] _UseMatcap ("Matcap", Float) = 0
        _MatcapTex ("Matcap", 2D) = "black" {}
        _MatcapStrength ("Matcap Strength", Range(0,1)) = 0

        [Toggle] _UseFakeLight ("Fake Light", Float) = 0
        _FakeLightColor ("Fake Light Color", Color) = (1,1,1,1)
        _FakeLightIntensity ("Fake Light Intensity", Range(0,3)) = 1
        _FakeLightDir ("Fake Light Direction", Vector) = (0,1,0,0)

        [Header(Textures)]
        [Toggle] _UseDetail ("Detail Overlay", Float) = 0
        _DetailTex ("Detail Texture", 2D) = "gray" {}
        _DetailTexTiling ("Detail Tiling", Vector) = (8,8,0,0)
        _DetailTexOffset ("Detail Offset", Vector) = (0,0,0,0)
        _DetailTexUVSelect ("Detail UV Select", Range(0,1)) = 0
        _DetailStrength ("Detail Strength", Range(0,2)) = 0.2
        _DetailBlend ("Detail Blend", Range(0,1)) = 1

        [Normal] _BumpMap ("Normal Map", 2D) = "bump" {}
        _BumpStrength ("Normal Strength", Range(0,2)) = 0.4

        [Toggle] _UseParallax ("Use Parallax", Float) = 0
        _ParallaxStrength ("Parallax Strength", Range(0,0.1)) = 0.02

        _OcclusionMap ("Occlusion Map", 2D) = "white" {}
        _OcclusionStrength ("Occlusion Strength", Range(0,1)) = 1

        _MetallicMap ("Metallic Map", 2D) = "black" {}
        _MetallicStrength ("Metallic Strength", Range(0,1)) = 0

        _SmoothnessMap ("Smoothness Map", 2D) = "black" {}
        _SmoothnessStrength ("Smoothness Strength", Range(0,1)) = 0

        _HeightMap ("Height Map", 2D) = "black" {}
        _HeightStrength ("Height Strength", Range(0,2)) = 0

        [Header(Effects - Emission)]
        [Toggle] _UseEmission ("Emission", Float) = 0
        _EmissionMap ("Emission Map", 2D) = "black" {}
        _EmissionMask ("Emission Mask", 2D) = "white" {}
        _EmissionColor ("Emission Color", Color) = (0.1,0.7,1,1)
        _EmissionStrength ("Emission Strength", Range(0,8)) = 1
        _EmissionPulseSpeed ("Pulse Speed", Range(0,10)) = 0
        _EmissionPulseMin ("Pulse Min", Range(0,1)) = 0.5
        _EmissionFlickerSpeed ("Flicker Speed", Range(0,20)) = 0
        _EmissionFlickerIntensity ("Flicker Intensity", Range(0,1)) = 0
        _EmissionScrollSpeed ("Scroll Speed", Range(0,10)) = 0
        _EmissionScrollDirection ("Scroll Direction", Range(0,360)) = 0

        [Header(Effects - Outline)]
        [Toggle] _UseOutline ("Outline", Float) = 0
        _OutlineColor ("Outline Color", Color) = (0,0,0,1)
        _OutlineWidth ("Outline Width", Range(0,0.1)) = 0
        _OutlineThreshold ("Outline Threshold", Range(0,1)) = 0.1
        _OutlineMask ("Outline Mask", 2D) = "white" {}
        _OutlineTransparency ("Outline Transparency", Range(0,1)) = 0
        _OutlineDistanceScale ("Outline Distance Scale", Range(0,1)) = 0.5

        [Header(Effects - Iridescent)]
        [Toggle] _UseIridescent ("Iridescent", Float) = 0
        _IridescentStrength ("Iridescent Strength", Range(0,2)) = 0
        _IridescentColor ("Iridescent Color", Color) = (1,1,1,1)
        _IridescentShift ("Iridescent Shift", Range(0,1)) = 0.5

        [Header(Effects - Glitter)]
        [Toggle] _UseGlitter ("Glitter", Float) = 0
        _GlitterTex ("Glitter Texture", 2D) = "white" {}
        _GlitterStrength ("Glitter Strength", Range(0,2)) = 0.5
        _GlitterSize ("Glitter Size", Range(0.001,0.05)) = 0.01
        _GlitterThreshold ("Glitter Threshold", Range(0,1)) = 0.5

        [Header(Effects - Dissolve)]
        [Toggle] _UseDissolve ("Dissolve", Float) = 0
        _DissolveAmount ("Dissolve Amount", Range(0,1)) = 0
        _DissolveEdgeWidth ("Dissolve Edge Width", Range(0,0.1)) = 0.05
        _DissolveEdgeColor ("Dissolve Edge Color", Color) = (1,0.5,0,1)

        [Header(Effects - Gradient)]
        [Toggle] _UseGradient ("Gradient", Float) = 0
        _GradientTex ("Gradient Texture", 2D) = "white" {}
        _GradientStrength ("Gradient Strength", Range(0,1)) = 0

        [Header(Effects - Decal)]
        [Toggle] _UseDecal ("Decal", Float) = 0
        _DecalTex ("Decal Texture", 2D) = "white" {}
        _DecalStrength ("Decal Strength", Range(0,1)) = 0
        _DecalTiling ("Decal Tiling", Vector) = (1,1,0,0)
        _DecalOffset ("Decal Offset", Vector) = (0,0,0,0)

        [Header(Advanced)]
        [Enum(Off,0,Back,2,Front,1)] _CullMode ("Cull Mode", Float) = 2
        [Toggle] _ZWrite ("ZWrite", Float) = 0
        _RenderQueue ("Render Queue", Float) = 3000

        [Toggle] _CastShadows ("Cast Shadows", Float) = 1
        [Toggle] _ReceiveShadows ("Receive Shadows", Float) = 1

        [Toggle] _UseStencil ("Use Stencil", Float) = 0
        _StencilRef ("Stencil Ref", Float) = 1
        [Enum(Always,0,Equal,3,NotEqual,4)] _StencilComp ("Stencil Comp", Float) = 3
        [Enum(Replace,2,Increment,1,Decrement,3,Keep,0)] _StencilPass ("Stencil Pass", Float) = 2
        [Enum(Keep,0,Zero,1,Replace,2,IncrSat,3,DecrSat,4,Invert,5)] _StencilFail ("Stencil Fail", Float) = 0

        [Toggle] _UseAudioLink ("Use AudioLink", Float) = 0
        [Enum(Bass,0,LowMid,1,HighMid,2,Treble,3)] _AudioLinkBand ("AudioLink Band", Float) = 0
        _AudioLinkStrength ("AudioLink Strength", Range(0,2)) = 1

        _FinalGlowPower ("Final Glow Power", Range(0,3)) = 1
    }

    SubShader
    {
        Tags
        {
            "Queue"="Transparent"
            "RenderType"="Transparent"
            "IgnoreProjector"="True"
        }

        LOD 400

        Stencil
        {
            Ref [_StencilRef]
            Comp [_StencilComp]
            Pass [_StencilPass]
            Fail [_StencilFail]
        }

        Cull [_CullMode]
        ZWrite [_ZWrite]
        Blend SrcAlpha OneMinusSrcAlpha

        CGPROGRAM
        #pragma surface surf StandardSpecular alpha:fade
        #pragma target 3.0

        #pragma multi_compile _USE_TOON_LIGHTING _USE_TOON_LIGHTING_OFF
        #pragma multi_compile _USE_DETAIL _USE_DETAIL_OFF
        #pragma multi_compile _USE_NORMAL _USE_NORMAL_OFF
        #pragma multi_compile _USE_RIM_LIGHT _USE_RIM_LIGHT_OFF
        #pragma multi_compile _USE_FRESNEL _USE_FRESNEL_OFF
        #pragma multi_compile _USE_MATCAP _USE_MATCAP_OFF
        #pragma multi_compile _USE_FAKE_LIGHT _USE_FAKE_LIGHT_OFF
        #pragma multi_compile _USE_EMISSION _USE_EMISSION_OFF
        #pragma multi_compile _USE_OUTLINE _USE_OUTLINE_OFF
        #pragma multi_compile _USE_DISSOLVE _USE_DISSOLVE_OFF
        #pragma multi_compile _USE_GRADIENT _USE_GRADIENT_OFF
        #pragma multi_compile _USE_DECAL _USE_DECAL_OFF
        #pragma multi_compile _USE_STENCIL _USE_STENCIL_OFF
        #pragma multi_compile _USE_AUDIOLINK _USE_AUDIOLINK_OFF
        #pragma multi_compile _USE_IRIDESCENT _USE_IRIDESCENT_OFF
        #pragma multi_compile _USE_GLITTER _USE_GLITTER_OFF
        #pragma multi_compile _USE_PARALLAX _USE_PARALLAX_OFF
        #pragma multi_compile _USE_SHADE_RAMP _USE_SHADE_RAMP_OFF

        sampler2D _MainTex;
        sampler2D _DetailTex;
        sampler2D _BumpMap;
        sampler2D _HeightMap;
        sampler2D _OcclusionMap;
        sampler2D _MetallicMap;
        sampler2D _SmoothnessMap;
        sampler2D _EmissionMap;
        sampler2D _EmissionMask;
        sampler2D _MatcapTex;
        sampler2D _GradientTex;
        sampler2D _DecalTex;
        sampler2D _OutlineMask;
        sampler2D _GlitterTex;
        sampler2D _ShadeRampTex;
        sampler2D _RimMask;

        fixed4 _Color;
        half _Alpha;

        half _Brightness;
        half _Contrast;
        half _Saturation;
        half _HueShift;
        half _Gamma;
        half _Vibrance;
        half _Sharpness;

        half _ShadowStrength;
        half _ShadowThreshold;
        half _ShadowSmoothness;
        fixed4 _ShadowColor;
        half _UseCelShading;
        half3 _ToonLightDir;

        fixed4 _RimColor;
        half _RimPower;
        half _RimStrength;
        half _RimWidth;

        fixed4 _FresnelColor;
        half _FresnelPower;
        half _FresnelStrength;

        half _MatcapStrength;

        fixed4 _FakeLightColor;
        half _FakeLightIntensity;
        half3 _FakeLightDir;

        half _DetailStrength;
        half _DetailBlend;

        half _BumpStrength;

        half _Smoothness;
        half _MetallicStrength;
        half _SmoothnessStrength;
        half _HeightStrength;

        half _ParallaxStrength;

        fixed4 _EmissionColor;
        half _EmissionStrength;
        half _EmissionPulseSpeed;
        half _EmissionPulseMin;
        half _EmissionFlickerSpeed;
        half _EmissionFlickerIntensity;
        half _EmissionScrollSpeed;
        half _EmissionScrollDirection;

        fixed4 _OutlineColor;
        half _OutlineWidth;
        half _OutlineThreshold;
        half _OutlineTransparency;
        half _OutlineDistanceScale;

        half _IridescentStrength;
        fixed4 _IridescentColor;
        half _IridescentShift;

        half _GlitterStrength;
        half _GlitterSize;
        half _GlitterThreshold;

        half _DissolveAmount;
        half _DissolveEdgeWidth;
        fixed4 _DissolveEdgeColor;

        half _GradientStrength;

        half _DecalStrength;

        half _AudioLinkStrength;
        half _AudioLinkBand;

        half _FinalGlowPower;

        struct Input
        {
            float2 uv_MainTex;
            float2 uv_DetailTex;
            float2 uv_BumpMap;
            float2 uv_EmissionMap;
            float2 uv_EmissionMask;
            float2 uv_OcclusionMap;
            float2 uv_MetallicMap;
            float2 uv_SmoothnessMap;
            float2 uv_HeightMap;
            float2 uv_MatcapTex;
            float2 uv_GradientTex;
            float2 uv_DecalTex;
            float2 uv_OutlineMask;
            float2 uv_GlitterTex;
            float2 uv_ShadeRampTex;
            float2 uv_RimMask;
            float3 viewDir;
            float3 worldPos;
            float3 worldNormal;
            float3 worldViewDir;
            INTERNAL_DATA
        };

        fixed3 HueRotate(fixed3 c, half shift)
        {
            shift = shift / 360.0 + 1.0;
            fixed3 coshift = cos(shift * 6.2831853 + fixed3(0.0, 2.0943951, 4.1887902));
            half gray = dot(c, fixed3(0.299, 0.587, 0.114));
            return fixed3(
                gray + dot(c, fixed3(0.701, -0.587, -0.114) * coshift.x) + dot(c, fixed3(-0.299, -0.587, 0.701) * coshift.y) + dot(c, fixed3(-0.300, 0.587, -0.587) * coshift.z),
                gray + dot(c, fixed3(0.701, -0.587, -0.114) * coshift.x + 0.168736) + dot(c, fixed3(-0.299, -0.587, 0.701) * coshift.y + 0.328416) + dot(c, fixed3(-0.300, 0.587, -0.587) * coshift.z + 0.5),
                gray + dot(c, fixed3(0.701, -0.587, -0.114) * coshift.x + 0.5) + dot(c, fixed3(-0.299, -0.587, 0.701) * coshift.y + 0.330864) + dot(c, fixed3(-0.300, 0.587, -0.587) * coshift.z + 0.5)
            );
        }

        fixed3 GammaAdjust(fixed3 c, half g)
        {
            return pow(c, fixed3(1.0/g, 1.0/g, 1.0/g));
        }

        fixed3 VibranceAdjust(fixed3 c, half v)
        {
            half maxC = max(c.r, max(c.g, c.b));
            half minC = min(c.r, min(c.g, c.b));
            half sat = (maxC - minC) / (maxC + 0.0001);
            half boost = (1.0 - sat) * v;
            return c + boost * (maxC - c);
        }

        fixed3 ContrastAdjust(fixed3 c, half v)
        {
            return saturate((c - 0.5) * v + 0.5);
        }

        fixed3 SaturationAdjust(fixed3 c, half v)
        {
            half gray = dot(c, fixed3(0.299, 0.587, 0.114));
            return lerp(fixed3(gray, gray, gray), c, v);
        }

        fixed3 SharpnessAdjust(fixed3 c, half s, fixed3 blurred)
        {
            return lerp(blurred, c, 1.0 + s);
        }

        fixed3 ScrolledUV(fixed2 uv, half speed, half direction)
        {
            float rad = direction * 3.14159 / 180.0;
            fixed2 dir = fixed2(cos(rad), sin(rad));
            return tex2D(_MainTex, uv + dir * _Time.y * speed).rgb;
        }

        half2 ParallaxUV(half2 uv, half3 viewDir, half strength)
        {
            half2 offset = viewDir.xy * strength;
            return uv - offset;
        }

        void surf(Input IN, inout SurfaceOutputStandardSpecular o)
        {
            #if _USE_PARALLAX
                half2 parallaxUV = ParallaxUV(IN.uv_MainTex, IN.viewDir, _ParallaxStrength);
                fixed4 mainTex = tex2D(_MainTex, parallaxUV);
            #else
                fixed4 mainTex = tex2D(_MainTex, IN.uv_MainTex);
            #endif
            fixed3 col = mainTex.rgb * _Color.rgb;

            col = ContrastAdjust(col, _Contrast);
            col = SaturationAdjust(col, _Saturation);
            col *= _Brightness;
            col = HueRotate(col, _HueShift);
            col = GammaAdjust(col, _Gamma);
            col = VibranceAdjust(col, _Vibrance);

            #if _USE_DETAIL
                fixed2 detailUV = lerp(IN.uv_MainTex, IN.uv_DetailTex, _DetailTexUVSelect);
                detailUV = detailUV * _DetailTexTiling.xy + _DetailTexOffset.xy;
                fixed3 detail = tex2D(_DetailTex, detailUV).rgb;
                col *= lerp(fixed3(1,1,1), detail * 2.0, _DetailStrength * _DetailBlend);
            #endif

            #if _USE_NORMAL
                fixed3 n = UnpackNormal(tex2D(_BumpMap, IN.uv_BumpMap));
                o.Normal = lerp(fixed3(0,0,1), n, _BumpStrength);
            #endif

            half fresnel = 1.0 - saturate(dot(normalize(IN.viewDir), o.Normal));

            fixed3 emission = fixed3(0,0,0);

            #if _USE_RIM_LIGHT
                half rimMask = tex2D(_RimMask, IN.uv_RimMask).r;
                half rim = pow(fresnel, _RimPower) * _RimStrength * _RimWidth * rimMask;
                emission += _RimColor.rgb * rim;
            #endif

            #if _USE_FRESNEL
                half fresnelEffect = pow(fresnel, _FresnelPower) * _FresnelStrength;
                emission += _FresnelColor.rgb * fresnelEffect;
            #endif

            #if _USE_EMISSION
                fixed3 e = tex2D(_EmissionMap, IN.uv_EmissionMap).rgb;
                fixed3 eMask = tex2D(_EmissionMask, IN.uv_EmissionMask).rgb;
                e *= eMask;
                e *= _EmissionColor.rgb * _EmissionStrength;
                e *= _EmissionPulseSpeed > 0 ? _EmissionPulseMin + (1.0 - _EmissionPulseMin) * (0.5 + 0.5 * sin(_Time.y * _EmissionPulseSpeed * 6.28)) : 1.0;
                e *= _EmissionFlickerSpeed > 0 ? 1.0 - _EmissionFlickerIntensity * (0.5 + 0.5 * sin(_Time.y * _EmissionFlickerSpeed * 6.28)) * (0.5 + 0.5 * sin(_Time.y * _EmissionFlickerSpeed * 12.56)) : 1.0;
                fixed2 scrollUV = IN.uv_EmissionMap;
                float rad = _EmissionScrollDirection * 3.14159 / 180.0;
                scrollUV += fixed2(cos(rad), sin(rad)) * _Time.y * _EmissionScrollSpeed;
                e *= tex2D(_EmissionMap, scrollUV).rgb;
                emission += e;
            #endif

            #if _USE_MATCAP
                half2 matcapUV = o.Normal.xy * 0.5 + 0.5;
                emission += tex2D(_MatcapTex, matcapUV).rgb * _MatcapStrength;
            #endif

            #if _USE_GRADIENT
                fixed3 gradTex = tex2D(_GradientTex, IN.uv_MainTex).rgb;
                emission += gradTex * gradTex.r * _GradientStrength;
            #endif

            #if _USE_IRIDESCENT
                half iridescence = dot(normalize(IN.viewDir), o.Normal);
                iridescence = pow(1.0 - iridescence, _IridescentShift * 8.0 + 1.0);
                fixed3 iriCol = _IridescentColor.rgb;
                iriCol = HueRotate(iriCol, _Time.y * 20.0 * _IridescentShift);
                emission += iriCol * iridescence * _IridescentStrength;
            #endif

            #if _USE_GLITTER
                fixed2 glitterUV = IN.worldPos.xy * 0.1 + _Time.y * 0.5;
                fixed3 glitter = tex2D(_GlitterTex, glitterUV).rgb;
                half glitterMask = step(_GlitterThreshold, glitter.r);
                half glitterSize = _GlitterSize * 100.0;
                half sparkle = glitterMask * glitterSize / (abs(fresnel - glitter.r) + glitterSize);
                emission += sparkle * _GlitterStrength;
            #endif

            #if _USE_DISSOLVE
                half dissolve = mainTex.a - _DissolveAmount;
                clip(dissolve);
                if (dissolve < _DissolveEdgeWidth)
                {
                    emission += _DissolveEdgeColor.rgb * (1.0 - dissolve / _DissolveEdgeWidth);
                }
            #endif

            o.Albedo = saturate(col);

            #if _USE_DECAL
                fixed3 decal = tex2D(_DecalTex, IN.uv_DecalTex).rgb;
                o.Albedo = lerp(o.Albedo, o.Albedo * decal, _DecalStrength);
            #endif

            half metallic = tex2D(_MetallicMap, IN.uv_MetallicMap).r * _MetallicStrength;
            half smoothness = tex2D(_SmoothnessMap, IN.uv_SmoothnessMap).r * _SmoothnessStrength;
            half finalSmoothness = lerp(_Smoothness, smoothness, _SmoothnessStrength);
            o.Specular = fixed3(metallic, metallic, metallic);
            o.Specular.a = finalSmoothness;

            half occ = tex2D(_OcclusionMap, IN.uv_OcclusionMap).r;
            o.Albedo *= lerp(1.0, occ, _OcclusionStrength);

            o.Emission = emission * _FinalGlowPower;

            #if _USE_TOON_LIGHTING
                half NdotL = dot(o.Normal, normalize(_ToonLightDir));
                half shadow = smoothstep(_ShadowThreshold - _ShadowSmoothness, _ShadowThreshold + _ShadowSmoothness, NdotL);
                #if _USE_SHADE_RAMP
                    fixed3 ramp = tex2D(_ShadeRampTex, fixed2(shadow, 0.5)).rgb;
                    col = lerp(col * _ShadowColor.rgb, col, shadow * _ShadowStrength + (1.0 - _ShadowStrength));
                    col = lerp(col, col * ramp, 0.5);
                #else
                    if (_UseCelShading > 0.5)
                    {
                        shadow = step(_ShadowThreshold, NdotL);
                    }
                    col = lerp(col * _ShadowColor.rgb, col, shadow * _ShadowStrength + (1.0 - _ShadowStrength));
                #endif
                o.Albedo = saturate(col);
            #endif

            half alpha = mainTex.a * _Color.a * _Alpha;

            #if _USE_AUDIOLINK
                half audioVal = 0;
                if (_AudioLinkBand < 0.5) audioVal = AudioLinkData.audiolink[0];
                else if (_AudioLinkBand < 1.5) audioVal = AudioLinkData.audiolink[16];
                else if (_AudioLinkBand < 2.5) audioVal = AudioLinkData.audiolink[32];
                else audioVal = AudioLinkData.audiolink[48];
                o.Emission += audioVal * _AudioLinkStrength * _Color.rgb;
            #endif

            o.Alpha = saturate(alpha);
        }
        ENDCG
    }

    FallBack "Transparent/Diffuse"
    CustomEditor "BlueysTextureGUI"
}